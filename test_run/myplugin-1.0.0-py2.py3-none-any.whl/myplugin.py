print("hello world from .whl pytest plugin")
